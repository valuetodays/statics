
打开chrome://extensions/，开启开发者械，点“加载已解压的扩展程序”，选择manifest.json所在的目录。


