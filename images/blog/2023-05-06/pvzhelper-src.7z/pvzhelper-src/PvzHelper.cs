using System;
using System.Collections.Generic;
using System.IO;
using System.Security.Cryptography;
using System.Text;
using System.Globalization;
using System.Runtime.InteropServices;

using util;

public class PvzHelper {

    [DllImport("kernel32.dll", SetLastError = true)]
    static extern int ReadProcessMemory(int hProcess, int lpBaseAddress, ref int buffer, int size, int lpNumberOfBytesRead);

    [DllImport("kernel32.dll", SetLastError = true)]
    public static extern bool WriteProcessMemory(int hProcess, int lpBaseAddress, ref int lpBuffer, int nSize, int lpNumberOfBytesWritten);

    [DllImport("kernel32.dll")]
    public static extern int OpenProcess(int processAccess, bool bInheritHandle, int processId);

    [DllImport("user32.dll")]
    public static extern bool GetWindowThreadProcessId(int hWnd, ref int lpdwProcessId);

    [DllImport("user32.dll", SetLastError = true)]
    public static extern int FindWindow(string lpClassName, string lpWindowName);

    [DllImport("kernel32.dll")]
    public static extern int CloseHandle(int hObject);

    public const int PROCESS_ALL_ACCESS = 2035711;

    public static void Main (string[] args) {
        // 游戏进程标识
        int ppid = int.MinValue; 
        // 查找"植物大战僵尸汉化版"窗口句柄
        int hwnd = FindWindow(null, "植物大战僵尸汉化版"); 
        if (hwnd <= 0) {
            CommonUtil.pressAnyKeyToExit("pvz is not running");
            return;
        }
        // 取与窗口关联的进程标识
        GetWindowThreadProcessId(hwnd, ref ppid); 

        // 进程句柄
        int hProcess = OpenProcess(PROCESS_ALL_ACCESS, false, ppid); 
        // [[[006A9EC0]->768]->5560]
        int esi = 0, edi = 0;
        // 基址(base_addr) 006A9EC0
        ReadProcessMemory(hProcess, 0x006A9EC0, ref esi, 4, 0);
        int leve1OneOffset = int.Parse("768", NumberStyles.HexNumber);
        const int levelTwoOffset = 0x5560;
        // mov edi,[esi+00000768]
        ReadProcessMemory(hProcess, esi + leve1OneOffset, ref edi, 4, 0);
        // mov [edi+00005560],esi
        int sunValuePointer = edi + levelTwoOffset;
        int sunValue = -1;
        while (true) {
            // 获取阳光
            ReadProcessMemory(hProcess, sunValuePointer, ref sunValue, 4, 0); 
            Console.Write ("\n\ncurrent sun valuse is " + sunValue + "\n");
            String msg = "do you want to get more 1000 sun? [y]";
            Console.Write(msg);
            ConsoleKeyInfo cki = Console.ReadKey(true);
            if (cki.Key == ConsoleKey.Enter) {
                continue;
            } else if (cki.Key != ConsoleKey.Y) {
                Console.Write("pvzhelper will exit\n");
                break;
            }
            sunValue += 1000;
            // 修改阳光
            WriteProcessMemory(hProcess, sunValuePointer, ref sunValue, 4, 0); 
        }

        // 关闭内核对象
        CloseHandle(hProcess); 

        CommonUtil.pressAnyKeyToExit("\nDone");
        return;
    }
}