﻿using System;
using System.Text;

namespace util
{


    public class CommonUtil
    {

        public static void pressAnyKeyToExit(string prefixMsg)
        {
            Console.Write (prefixMsg + ", Press any key to exit.");
            Console.ReadKey ();
        }


    }
}
