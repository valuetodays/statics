package jee.billy.helloeatj.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * @author liulei
 *
 */
public class DemoServlet extends HttpServlet {

    private static final long serialVersionUID = 1L;
    private static final String PAGE_PATH = "/WEB-INF/pages/";

    
    
    private void doDemo(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String name = req.getParameter("name");
        if (name == null || "".equals(name)) {
            name = "billy";
        }
        
        req.setAttribute("name", name);
        req.getRequestDispatcher(PAGE_PATH + "demo/index.jsp").forward(req, resp);
    }

    
    
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        doDemo(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        doDemo(req, resp);        
    }

    
}
