### Apache Ant 1.1 源码编译环境搭建

前半年公司要实现一个小功能，得用Apache Ant来完成。正好工作交给了我，我在完成功能之后花了几天看了下它的源代码(ver1.9.6)，里面的东西很多很复杂，仅仅是找源码所依赖的jar包就找了好长时间，到最后也只是模模糊糊的，对Ant的源码也没有一个很深的认识。这几天手又有点痒，还想看看它的源代码，不过这次不看1.9.6的了，要看就看第一个版本！


#### 下载源码

说找就找，直接 [http://ant.apache.org/](http://ant.apache.org/)，然后点击左边菜单Download --> Source Distributions，该页面中间有段话

    Older releases of Ant can be found here. 

其中`here`对应的是一个链接 [http://archive.apache.org/dist/ant/source/](http://archive.apache.org/dist/ant/source/)，在里面找到了1.1的版本。共下载三个文件：

- jakarta-ant-1.1.zip
- jakarta-ant-1.1-optional.jar
- RELEASE-NOTES-1.1

#### 准备环境

将zip文件解压就可以了，其中的src文件夹下就是源码了。
为了编译，我们得建立一个Java工程，下面以在eclipse中的操作为例说明，顺便说一下，我用的jdk是1.7，eclipse是Mars.2 Release (4.5.2)。
建立好工程后，将ant解压目录下src文件夹下的所有文件复制到工程下的src文件夹下。这时会报各种错(我机器上显示89 errors, 591 warnings)。
![](001.png)



- 最多的错误该算是enum导致的

![](002_enum.png)

    Enumeration enum = props.propertyNames();
    while (enum.hasMoreElements()) {
        String key = (String) enum.nextElement();
    }

enum在jdk1.5才出现，当时enum还不是关键字，可以将编译器的版本调到1.3，具体操作是
 
    右键工程 --> properties --> Java Compiler --> Enable project specific settings --> Compiler compliance leve --> 1.3 --> OK
    
这个时候错误数减少到48。

- 类org.apache.tools.ant.taskdefs.Javac中引用的sun.tools.javac.Main找不到，只需要将%JAVA_HOME%/lib/tools.jar加载到工程classpath下即可。

- 类org.apache.tools.ant.taskdefs.optional.NetRexxC缺少COM.ibm.netrexx.process.NetRexxC，将NetRexxC.jar加载到classpath下即可。

- 类org.apache.xalan.xslt.XSLTProcessorFactory、org.apache.xalan.xslt.XSLTProcessor、org.apache.xalan.xslt.XSLTInputSource还会报错，这个类很不好找，网上说的xalan-2.7.1.jar都不行。我在百度上找找了很久也没找到。无意之中在[http://archive.apache.org/dist/xml/xalan-j/](http://archive.apache.org/dist/xml/xalan-j/)找到了（我也想不起来是怎么找到的了），将xalan-j_1_0_0.tar.gz下载解压，里面有xalan.jar(即xalan-1.0.0.jar)，将它放到classpath下，问题解决。

- 类javax.ejb.deployment.EntityDescriptor就更难找了。找了好久无意找到一个网页[http://mail-archives.apache.org/mod_mbox/ant-user/200307.mbox/%3CA220D2C5610C714BA00110F541A4ABD901EC7765@home.fsoft.fpt.vn%3E](http://mail-archives.apache.org/mod_mbox/ant-user/200307.mbox/%3CA220D2C5610C714BA00110F541A4ABD901EC7765@home.fsoft.fpt.vn%3E)
在里面看到了ejb10deployment.jar这个包，可是在网上没有找到。接着在http://www.programgo.com/article/39421513082/找到了jdk1.3 j2sdkee-1_3_1-win.exe，以这个文件名搜索后在[http://download.csdn.net/download/extoxion/5694631](http://download.csdn.net/download/extoxion/5694631)花了一个积分下载成功，安装后在目录下找到ejb10deployment.jar，将它放到classpath下即可(最后会提供下载)，同时，和它并列的还有个bsf-1.0.jar，项目编译也需要它。

- 最难找的就是它了：com.kvisco.xsl.XSLProcessor，在百度上搜就三条记录，其中一条是[http://bbs.csdn.net/topics/80489524](http://bbs.csdn.net/topics/80489524)，里面也是没有找到资源。

- 遗憾的是，我也没有找到类weblogic.ejb.utils.DDCreator，我也没有使用过weblogic，网上说weblogic6.0的安装目录下可以找到这个文件。


这个时候项目还有错，但是不影响基本的运行。我们新建一个测试文件build.xml放在项目的根目录下，它的内容如下：

    <project name="helloProject" default="hello">
      <target name="hello" >
          <echo message="init..." />
      </target>
    </project>

然后进到org.apache.tools.ant.Main类中，右键Run As --> Java Application.即可正常运行。


附：
- 其实ant1.1里的东西是很少的，就几个核心的类，但麻雀虽小五脏俱全啊，从最初版本开始研究能更快地了解到核心。

- 把项目中的error处理掉真的不容易啊，这些早期的项目jar包真不好找。我在找的过程中看了好多英文网页，jakarta-ant-1.1.zip竟然是2003-08-12的文件，13年了！还有这个页面[https://git-wip-us.apache.org/repos/asf?p=ant.git;a=tags](https://git-wip-us.apache.org/repos/asf?p=ant.git;a=tags)的提交是16年前的。真想说句”好早啊“。

![](003_ant_tag.png)

- 很遗憾，项目中还有error，如果本文给您一种想研究ant1.1源代码的冲动，您又处理完了所有的error，请邮件通知我(193002818@qq.com)一声，十分感激。


也没有什么要说的了。谢谢浏览。
