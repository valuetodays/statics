==== 说明 ====

1. readme.md是发表在oschina.net的博客文件，该博客地址是https://my.oschina.net/valuetodays/blog/749245

2. 该项目主要用于演示从HttpServletResponse里拿到PrintWriter的内容

2016-09-20 17:16

