package com.billy.vt.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.lang.reflect.Field;

import javax.servlet.http.HttpServletResponse;

import org.apache.catalina.connector.CoyoteWriter;
import org.apache.catalina.connector.OutputBuffer;
import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

/**
 * index controller
 * 
 * @author vt
 */
@Controller
@RequestMapping("/index")
public class IndexController {
    private static Logger LOG = Logger.getLogger(IndexController.class);
    
    
    /**
     * read data from {@link HttpServletResponse}
     * 
     * http://127.0.0.1:9000/tester/index/response.do
     * @param response 
     */
    @RequestMapping(method = RequestMethod.GET, value = "/response")
    public void doGetDataFromResponse(HttpServletResponse response) {
        PrintWriter writer = null;
        try {
            writer = response.getWriter();
            String msg = "<xml><msg>hahah</msg><createAt>"
                    +System.currentTimeMillis()+"</createAt></xml>";
            writer.print(msg);
            writer.flush();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (writer != null) {
                writer.close();
            }
        }
        
        try {
//            response.flushBuffer();
            PrintWriter writerToBeRead = response.getWriter();
            System.out.print(writerToBeRead.getClass().getName());
            CoyoteWriter cw = (CoyoteWriter)writerToBeRead;
            LOG.debug(cw.getClass().getName());
            Class<?> clazz = cw.getClass();
            Field declaredField = clazz.getDeclaredField("ob");
            declaredField.setAccessible(true);
            OutputBuffer ob = (OutputBuffer)declaredField.get(cw);
            LOG.debug(ob);
            Class<?> classOutputBuffer = ob.getClass();
            Field fieldOutputChunk = classOutputBuffer.getDeclaredField("outputChunk");
            fieldOutputChunk.setAccessible(true);
            Object object = fieldOutputChunk.get(ob);
            LOG.info(object.getClass().getName());
            LOG.info("text from response: "+ object);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
}
