package cn.valuetodays.consumer;

import cn.valuetodays.common.service.DubboServiceConstant;
import cn.valuetodays.common.service.HelloService;
import org.apache.dubbo.config.annotation.DubboReference;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * .
 *
 * @author lei.liu
 * @since 2025-06-03
 */
@RestController
public class IndexController {
    @DubboReference(group = DubboServiceConstant.API_PROVIDER_GROUP, version = "1.0.0", timeout = 30000, retries = 3)
    private HelloService helloService;

    @RequestMapping("")
    public String hi(String name) {
        return helloService.hi(name);
    }
}
