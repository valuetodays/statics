package cn.valuetodays.common.service;

/**
 * .
 *
 * @author lei.liu
 * @since 2025-06-03
 */
public interface HelloService {
    String hi(String name);
}
