package cn.valuetodays.common.service;

/**
 * .
 *
 * @author lei.liu
 * @since 2025-06-03
 */
public class DubboServiceConstant {
    public static final String API_PROVIDER_GROUP = "provider";
}
