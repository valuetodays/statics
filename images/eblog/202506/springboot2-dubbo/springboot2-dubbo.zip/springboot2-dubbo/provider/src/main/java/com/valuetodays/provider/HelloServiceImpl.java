package com.valuetodays.provider;

import cn.valuetodays.common.service.DubboServiceConstant;
import cn.valuetodays.common.service.HelloService;
import org.apache.dubbo.config.annotation.DubboService;

/**
 * .
 *
 * @author lei.liu
 * @since 2025-06-03
 */
@DubboService(group = DubboServiceConstant.API_PROVIDER_GROUP, version = "1.0.0", timeout = 30000)
public class HelloServiceImpl implements HelloService {
    @Override
    public String hi(String name) {
        return "hi, " + name;
    }
}
