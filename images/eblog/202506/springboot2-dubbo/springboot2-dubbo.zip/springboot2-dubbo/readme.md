
先启动nacos
再启动provider
再启动consumer，会看到打印了hi,aaa

再 curl http://localhost:60001?name=billy