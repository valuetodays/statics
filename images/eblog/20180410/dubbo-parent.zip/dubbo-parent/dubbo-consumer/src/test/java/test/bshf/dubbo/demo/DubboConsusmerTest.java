package test.bshf.dubbo.demo;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import com.bshf.demo.dubbo.service.DemoService;
import com.bshf.demo.dubbo.vo.DemoVO;

import test.bshf.dubbo.demo.base.SpringBaseTest;

public class DubboConsusmerTest extends SpringBaseTest {
    @Autowired
    @Qualifier("demoServiceConsumer")
    private DemoService demoServiceConsumer;
    
    @Test
    public void testDubbo() throws InterruptedException {
        System.out.println(demoServiceConsumer.getClass().getName());
        for (int i = 0; i < 10; i++) {
            DemoVO v = demoServiceConsumer.getByID(i);
            System.out.println(v);
            Thread.sleep(1000);
        }
    }
}
