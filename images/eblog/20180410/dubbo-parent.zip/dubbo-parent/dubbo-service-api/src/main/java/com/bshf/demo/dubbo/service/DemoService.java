package com.bshf.demo.dubbo.service;

import com.bshf.demo.dubbo.vo.DemoVO;

public interface DemoService {

    DemoVO getByID(Integer id);

}
