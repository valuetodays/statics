import org.springframework.context.support.ClassPathXmlApplicationContext;

import java.io.IOException;

/**
 * 启动web服务
 *
 * @author liulei@bshf360.com
 * @since 2018-04-10 09:29
 */
public class ProviderStarter {
    public static void main(String[] args) {
        String[] springConfXmls = new String[]{"classpath*:spring/applicationContext-*.xml"};
        ClassPathXmlApplicationContext ac =
                new ClassPathXmlApplicationContext(springConfXmls);
        ac.start();
        System.out.println("started");

        // press any key to exit
        try {
            System.in.read();
        } catch (IOException e) {
//            e.printStackTrace();
        }
    }
}
