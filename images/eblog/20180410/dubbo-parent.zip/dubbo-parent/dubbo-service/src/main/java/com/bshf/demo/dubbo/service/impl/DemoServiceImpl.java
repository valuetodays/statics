package com.bshf.demo.dubbo.service.impl;

import java.util.Date;

import org.springframework.stereotype.Service;

import com.bshf.demo.dubbo.service.DemoService;
import com.bshf.demo.dubbo.vo.DemoVO;

/**
 * 
 */
@Service
public class DemoServiceImpl implements DemoService {
    
    public String staticResourcesServer;
    public String times;
    

    @Override
    public DemoVO getByID(Integer id) {
        DemoVO v = new DemoVO();
        v.setId(id);
        v.setCreateDate(new Date());
        v.setTitle(System.currentTimeMillis() + "");
        v.setVersion(System.currentTimeMillis() + 100L);
        
        return v;
    }


}
