// Maze32.cpp : ����Ӧ�ó������ڵ㡣
//

#include "stdafx.h"
#include "Maze32.h"

#define _tcscpy_s _tcscpy

#define MAX_LOADSTRING 100

#define WM_RESET		(WM_USER + 1)

#define RESET_INITIAL	1
#define RESET_COMPLETE	2
#define RESET_ERROR		3

#define ERROR_OUTOFRANGE	1
#define ERROR_NOMEMORY		2

#define ROUTE_SIZE	10
#define BLOCK_SIZE	2
#define SQU_SIZE	(ROUTE_SIZE + BLOCK_SIZE * 2)

#ifdef _DEBUG
#define SQU_MARGIN (BLOCK_SIZE)
#else
#define SQU_MARGIN (-BLOCK_SIZE)
#endif

#define MARGIN_X	10
#define MARGIN_Y	10

// ȫ�ֱ���:
HINSTANCE hInst;								// ��ǰʵ��
TCHAR szTitle[MAX_LOADSTRING];					// �������ı�
TCHAR szWindowClass[MAX_LOADSTRING];			// ����������

TCHAR szDebug[MAX_LOADSTRING];

static BOOL bReAlloc = TRUE;		// �Ƿ����·����ڴ�
static BOOL bInit = FALSE;			// �Ƿ��ѳ�ʼ��

static int cxMaze = 32;				// �Թ��������
static int cyMaze = 32;				// �Թ�����߶�
static int nMazeWidth;				// �Թ����ƿ���
static int nMazeHeight;				// �Թ����Ƹ߶�

static int dxFlt = 0;				// ���������
static int dyFlt = 0;				// ����������

static MazeBuff ppMaze = NULL;		// �Թ�����
static LinkStack* pPath = NULL;		// �Թ�·�߻���

// �˴���ģ���а����ĺ�����ǰ������:
ATOM				MyRegisterClass(HINSTANCE hInstance);
BOOL				InitInstance(HINSTANCE, int);
LRESULT CALLBACK	WndProc(HWND, UINT, WPARAM, LPARAM);
LRESULT CALLBACK	MazeWndProc(HWND, UINT, WPARAM, LPARAM);
LRESULT CALLBACK	FloatWndProc(HWND, UINT, WPARAM, LPARAM);
LRESULT CALLBACK	About(HWND, UINT, WPARAM, LPARAM);
LRESULT CALLBACK	Config(HWND, UINT, WPARAM, LPARAM);
DWORD WINAPI ResetThread(LPVOID lpParam);
void DrawMaze(HDC hdc);
void DrawPath(HDC hdc);

int APIENTRY _tWinMain(HINSTANCE hInstance,
					   HINSTANCE hPrevInstance,
					   LPTSTR    lpCmdLine,
					   int       nCmdShow)
{
	UNREFERENCED_PARAMETER(hPrevInstance);
	UNREFERENCED_PARAMETER(lpCmdLine);

	// TODO: �ڴ˷��ô��롣

	MSG msg;
	HACCEL hAccelTable;

	// ��ʼ��ȫ���ַ���
	LoadString(hInstance, IDS_APP_TITLE, szTitle, MAX_LOADSTRING);
	LoadString(hInstance, IDC_MAZE32, szWindowClass, MAX_LOADSTRING);

	if (MyRegisterClass(hInstance) == 0)
		return 0;

	// ִ��Ӧ�ó����ʼ��:
	if (!InitInstance (hInstance, nCmdShow))
	{
		return FALSE;
	}

	hAccelTable = LoadAccelerators(hInstance, MAKEINTRESOURCE(IDC_MAZE32));

	// ����Ϣѭ��:
	while (GetMessage(&msg, NULL, 0, 0))
	{
		if (!TranslateAccelerator(msg.hwnd, hAccelTable, &msg))
		{
			TranslateMessage(&msg);
			DispatchMessage(&msg);
		}
	}

	return (int) msg.wParam;
}



//
//  ����: MyRegisterClass()
//
//  Ŀ��: ע�ᴰ���ࡣ
//
//  ע��:
//
//    ����ϣ��
//    �˴��������ӵ� Windows 95 �еġ�RegisterClassEx��
//    ����֮ǰ�� Win32 ϵͳ����ʱ������Ҫ�˺��������÷������ô˺���ʮ����Ҫ��
//    ����Ӧ�ó���Ϳ��Ի�ù�����
//    ����ʽ��ȷ�ġ�Сͼ�ꡣ
//
ATOM MyRegisterClass(HINSTANCE hInstance)
{
	WNDCLASSEX wcex;
	WNDCLASSEX wcexMaze;
	WNDCLASSEX wcexFloat;

	wcex.cbSize = sizeof(WNDCLASSEX);

	wcex.style			= CS_HREDRAW | CS_VREDRAW;
	wcex.lpfnWndProc	= WndProc;
	wcex.cbClsExtra		= 0;
	wcex.cbWndExtra		= 0;
	wcex.hInstance		= hInstance;
	wcex.hIcon			= LoadIcon(hInstance, MAKEINTRESOURCE(IDI_MAZE32));
	wcex.hCursor		= LoadCursor(NULL, IDC_ARROW);
	wcex.hbrBackground	= (HBRUSH)(COLOR_WINDOW+1);
	wcex.lpszMenuName	= MAKEINTRESOURCE(IDC_MAZE32);
	wcex.lpszClassName	= szWindowClass;
	wcex.hIconSm		= LoadIcon(wcex.hInstance, MAKEINTRESOURCE(IDI_SMALL));

	wcexMaze.cbSize = sizeof(WNDCLASSEX);

	wcexMaze.style			= CS_HREDRAW | CS_VREDRAW;
	wcexMaze.lpfnWndProc	= MazeWndProc;
	wcexMaze.cbClsExtra		= 0;
	wcexMaze.cbWndExtra		= 0;
	wcexMaze.hInstance		= hInstance;
	wcexMaze.hIcon			= NULL;
	wcexMaze.hCursor		= LoadCursor(NULL, IDC_ARROW);
	wcexMaze.hbrBackground	= (HBRUSH)(COLOR_WINDOW+1);
	wcexMaze.lpszMenuName	= NULL;
	wcexMaze.lpszClassName	= _T("MazeWnd");
	wcexMaze.hIconSm		= NULL;

	wcexFloat.cbSize = sizeof(WNDCLASSEX);

	wcexFloat.style			= CS_HREDRAW | CS_VREDRAW;
	wcexFloat.lpfnWndProc	= FloatWndProc;
	wcexFloat.cbClsExtra	= 0;
	wcexFloat.cbWndExtra	= 0;
	wcexFloat.hInstance		= hInstance;
	wcexFloat.hIcon			= NULL;
	wcexFloat.hCursor		= LoadCursor(NULL, IDC_ARROW);
	wcexFloat.hbrBackground	= CreateSolidBrush(0x00FFFF);
	wcexFloat.lpszMenuName	= NULL;
	wcexFloat.lpszClassName	= _T("FloatWnd");
	wcexFloat.hIconSm		= NULL;

	return RegisterClassEx(&wcex) & RegisterClassEx(&wcexMaze) & RegisterClassEx(&wcexFloat);
}

//
//   ����: InitInstance(HINSTANCE, int)
//
//   Ŀ��: ����ʵ�����������������
//
//   ע��:
//
//        �ڴ˺����У�������ȫ�ֱ����б���ʵ�������
//        ��������ʾ�����򴰿ڡ�
//
BOOL InitInstance(HINSTANCE hInstance, int nCmdShow)
{
	HWND hWnd;

	hInst = hInstance; // ��ʵ������洢��ȫ�ֱ�����

	hWnd = CreateWindow(szWindowClass, szTitle, WS_OVERLAPPEDWINDOW | WS_CLIPCHILDREN,
		CW_USEDEFAULT, 0, CW_USEDEFAULT, 0, NULL, NULL, hInstance, NULL);

	if (!hWnd)
	{
		return FALSE;
	}

	ShowWindow(hWnd, nCmdShow);
	UpdateWindow(hWnd);

	return TRUE;
}

//
//  ����: WndProc(HWND, UINT, WPARAM, LPARAM)
//
//  Ŀ��: ���������ڵ���Ϣ��
//
//  WM_COMMAND	- ����Ӧ�ó���˵�
//  WM_PAINT	- ����������
//  WM_DESTROY	- �����˳���Ϣ������
//
//
LRESULT CALLBACK WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	int wmId, wmEvent;
	PAINTSTRUCT ps;
	HDC hdc;
	SCROLLINFO si;
	RECT rt;

	static TCHAR szText[MAX_LOADSTRING];

	static int xSBPos = 0;				// ������λ��
	static int ySBPos = 0;

	static HWND hwndMaze = NULL;		// �����Թ��Ӵ���

	static HDC hdcMem = NULL;
	static HBITMAP hbmpMem = NULL;

	static WINDOWPLACEMENT wpFrame;		// ������λ����Ϣ

	int cxFrame, cyFrame;				// �����ڴ�С
	int cxClient, cyClient;				// �����ڿͻ�����С
	int cxBorder, cyBorder;				// �����ڱ߿��С���������������˵�����������

	static RECT rtFrame;				// �����ھ���
	static RECT rtClient;				// �����ڿͻ�������

	static RECT rtMaze;					// �Թ��Ӵ��ھ���

	switch (message)
	{
	case WM_CREATE:

		hwndMaze = CreateWindow(_T("MazeWnd"), NULL, WS_CHILD | WS_CLIPCHILDREN,
			0, 0, 0, 0,
			hWnd, NULL, hInst, NULL);

		SendMessage(hWnd, WM_RESET, MAKEWPARAM(RESET_INITIAL, 0), MAKELPARAM(cxMaze, cyMaze));

		hdcMem = CreateCompatibleDC(NULL);
		hbmpMem = CreateCompatibleBitmap(hdcMem, 1, 1);
		SelectObject(hdcMem, hbmpMem);
		SetRect(&rt, 0, 0, 1, 1);
		FillRect(hdcMem, &rt, NULL);
		break;

	case WM_RESET:

		switch (LOWORD(wParam))
		{
		case RESET_INITIAL:

			OutputDebugString(_T("RESET_INITAL\n"));

			bInit = FALSE;

			// ������������
			dxFlt = 0;
			dyFlt = 0;

			// ����Ѵ��ڵ�·��
			if (pPath != NULL)
			{
				destroyLinkStack(pPath);
				pPath = NULL;
			}

			// �� lParam ��Ϊ�������·�����·����
			if (lParam != NULL)
			{
				bReAlloc = TRUE;
				cxMaze = LOWORD(lParam);
				cyMaze = HIWORD(lParam);
			}

			// ��ʼ�����֮ǰ���ػ����Ӵ���
			ShowWindow(hwndMaze, SW_HIDE);


			// ��������Թ��Ĵ�С
			nMazeWidth = (SQU_SIZE + SQU_MARGIN) * cxMaze - SQU_MARGIN;
			nMazeHeight = (SQU_SIZE + SQU_MARGIN) * cyMaze - SQU_MARGIN;

			// ���������ڴ�Сǰ������λ�����㲢���ع�����
			si.fMask = SIF_POS;
			si.cbSize = sizeof(SCROLLINFO);
			si.nPos = 0;
			SetScrollInfo(hWnd, SB_HORZ, &si, TRUE);
			SetScrollInfo(hWnd, SB_VERT, &si, TRUE);

			ShowScrollBar(hWnd, SB_BOTH, FALSE);

			// �������ڲ������״̬ʱ���������ڴ�С
			GetClientRect(hWnd, &rtClient);
			cxClient = rtClient.right - rtClient.left;
			cyClient = rtClient.bottom - rtClient.top;

			GetWindowPlacement(hWnd, &wpFrame);

			if (wpFrame.showCmd != SW_MAXIMIZE)
			{
				SetRectEmpty(&rt);
				GetClientRect(hWnd, &rtClient);

				while (!EqualRect(&rt, &rtClient))
				{
					GetWindowRect(hWnd, &rtFrame);
					cxFrame = rtFrame.right - rtFrame.left;
					cyFrame = rtFrame.bottom - rtFrame.top;

					GetClientRect(hWnd, &rtClient);
					cxClient = rtClient.right - rtClient.left;
					cyClient = rtClient.bottom - rtClient.top;

					cxBorder = cxFrame - cxClient;
					cyBorder = cyFrame - cyClient;

					cxFrame = nMazeWidth + cxBorder + MARGIN_X * 2;
					cyFrame = nMazeHeight + cyBorder + MARGIN_Y * 2;

					SetWindowPos(hWnd, NULL, 0, 0, cxFrame, cyFrame, SWP_NOMOVE | SWP_FRAMECHANGED);

					/* ���������ڴ�Сʱ���ݻ����Թ��Ĵ�С�ж��Ƿ���ʾ������
					�����¼���ͻ�����С*/
					GetClientRect(hWnd, &rt);

					if (rt.right < nMazeWidth + MARGIN_X * 2)
						ShowScrollBar(hWnd, SB_HORZ, TRUE);

					if (rt.bottom < nMazeHeight + MARGIN_Y * 2)
						ShowScrollBar(hWnd, SB_VERT, TRUE);
				}
			}

			// ������������ʱ��ʾ�Ĺ�������������
			ShowScrollBar(hWnd, SB_BOTH, FALSE);

			_tcscpy_s(szText, _T("���ڻ����Թ�����"));

			RedrawWindow(hWnd, NULL, NULL, RDW_INVALIDATE | RDW_UPDATENOW);

			// ���㲢���������Ӵ��ڵ�λ�ü���С
			SetRect(&rtMaze, MARGIN_X, MARGIN_Y, MARGIN_X + nMazeWidth, MARGIN_Y + nMazeHeight);
			MoveWindow(hwndMaze, rtMaze.left, rtMaze.top, nMazeWidth, nMazeHeight, FALSE);

			// �жϻ��ƵĴ�С�Ƿ񳬳����ڴ�С���ֵ
			GetWindowRect(hwndMaze, &rt);
			MapWindowPoints(GetDesktopWindow(), hWnd, (LPPOINT)&rt, 2);

			if (!EqualRect(&rt, &rtMaze))
			{
				PostMessage(hWnd, WM_RESET, MAKELPARAM(RESET_ERROR, ERROR_OUTOFRANGE), NULL);
				break;
			}

			// ֪ͨ�����Ӵ��ڽ��г�ʼ������
			PostMessage(hwndMaze, message, wParam, lParam);
			break;

		case RESET_COMPLETE:

			OutputDebugString(_T("RESET_COMPLETE\n"));

			bInit = TRUE;
			bReAlloc = FALSE;

			GetClientRect(hWnd, &rt);

			// ���ݻ��ƴ�С�ж��Ƿ���ʾ������
			if (rt.right < nMazeWidth + MARGIN_X * 2)
				ShowScrollBar(hWnd, SB_HORZ, TRUE);

			if (rt.bottom < nMazeHeight + MARGIN_Y * 2)
				ShowScrollBar(hWnd, SB_VERT, TRUE);

			// ��ʾ�����Ӵ���
			RedrawWindow(hWnd, NULL, NULL, RDW_INVALIDATE | RDW_UPDATENOW);
			ShowWindow(hwndMaze, SW_SHOW);
			break;

		case RESET_ERROR:
			
			switch (HIWORD(wParam))
			{
			case ERROR_OUTOFRANGE:

				MessageBox(hWnd, _T("�������Ʒ�Χ��"), NULL, MB_OK);
				_tcscpy_s(szText, _T("�����˵���ʼ��Ϸ����"));
				RedrawWindow(hWnd, NULL, NULL, RDW_INVALIDATE | RDW_UPDATENOW);
				break;

			case ERROR_NOMEMORY:
				
				MessageBox(hWnd, _T("�޷������ڴ棡"), NULL, MB_OK);
				_tcscpy_s(szText, _T("�����˵���ʼ��Ϸ����"));
				RedrawWindow(hWnd, NULL, NULL, RDW_INVALIDATE | RDW_UPDATENOW);
				break;

			default:
				break;
			}
			break;

		default:
			break;
		}
		break;

	case WM_COMMAND:

		wmId    = LOWORD(wParam);
		wmEvent = HIWORD(wParam);
		// �����˵�ѡ��:
		switch (wmId)
		{
		case IDM_RESET:
			SendMessage(hWnd, WM_KEYDOWN, VK_F2, NULL);
			break;
		case IDM_SHOWPATH:
			SendMessage(hWnd, WM_KEYDOWN, VK_SPACE, NULL);
			break;
		case IDM_CONFIG:
			DialogBox(hInst, MAKEINTRESOURCE(IDD_CONFIG), hWnd, (DLGPROC)Config);
			break;
		case IDM_ABOUT:
			DialogBox(hInst, MAKEINTRESOURCE(IDD_ABOUTBOX), hWnd, (DLGPROC)About);
			break;
		case IDM_EXIT:
			DestroyWindow(hWnd);
			break;
		default:
			return DefWindowProc(hWnd, message, wParam, lParam);
		}
		break;

	case WM_SIZE:

		OutputDebugString(_T("WM_SIZE\n"));

		if (wParam == SIZE_MINIMIZED || !bInit)
			break;

		cxClient = LOWORD (lParam);
		cyClient = HIWORD (lParam);

		si.cbSize	= sizeof(si);
		si.fMask	= SIF_RANGE | SIF_PAGE;
		si.nMin		= 0;
		si.nMax		= nMazeWidth + MARGIN_X * 2 - 1;
		si.nPage	= cxClient;
		SetScrollInfo(hWnd, SB_HORZ, &si, TRUE);

		si.cbSize	= sizeof(si);
		si.fMask	= SIF_RANGE | SIF_PAGE;
		si.nMin		= 0;
		si.nMax		= nMazeHeight + MARGIN_Y * 2 - 1;
		si.nPage	= cyClient;
		SetScrollInfo(hWnd, SB_VERT, &si, TRUE);
		
		si.fMask = SIF_POS;
		GetScrollInfo (hWnd, SB_HORZ, &si);
		xSBPos = si.nPos;
		GetScrollInfo (hWnd, SB_VERT, &si);
		ySBPos = si.nPos;

		rtMaze.left = MARGIN_X - xSBPos;
		rtMaze.top = MARGIN_Y - ySBPos;
		rtMaze.right = rtMaze.left + nMazeWidth;
		rtMaze.bottom = rtMaze.top + nMazeHeight;
		MoveWindow(hwndMaze, rtMaze.left, rtMaze.top, nMazeWidth, nMazeHeight, FALSE);

		OutputDebugString(_T("WM_SIZE CHANGED\n"));
		break;

	case WM_HSCROLL:

		si.cbSize = sizeof (si);
		si.fMask  = SIF_ALL;
		GetScrollInfo (hWnd, SB_HORZ, &si);
		xSBPos = si.nPos;

		switch (LOWORD (wParam))
		{
			// user clicked left arrow
		case SB_LINELEFT: 
			si.nPos -= 1;
			break;
			// user clicked right arrow
		case SB_LINERIGHT: 
			si.nPos += 1;
			break;
			// user clicked the scroll bar shaft left of the scroll box
		case SB_PAGELEFT:
			si.nPos -= si.nPage;
			break;
			// user clicked the scroll bar shaft right of the scroll box
		case SB_PAGERIGHT:
			si.nPos += si.nPage;
			break;
			// user dragged the scroll box
		case SB_THUMBTRACK: 
			si.nPos = si.nTrackPos;
			break;
		default :
			break;
		}
		// Set the position and then retrieve it.  Due to adjustments
		// by Windows it may not be the same as the value set.
		si.fMask = SIF_POS;
		SetScrollInfo (hWnd, SB_HORZ, &si, TRUE);
		GetScrollInfo (hWnd, SB_HORZ, &si);
		// If the position has changed, scroll the window 
		if (si.nPos != xSBPos)
		{
			ScrollWindow(hWnd, xSBPos - si.nPos, 0, NULL, NULL);
			OffsetRect(&rtMaze, xSBPos - si.nPos, 0);
			xSBPos = si.nPos;
		}
		break;

	case WM_VSCROLL:

		si.cbSize = sizeof (si);
		si.fMask  = SIF_ALL;
		GetScrollInfo (hWnd, SB_VERT, &si);
		ySBPos = si.nPos;

		switch (LOWORD (wParam))
		{
			// user clicked the top arrow
		case SB_LINEUP:
			si.nPos -= 1;
			break;
			// user clicked the bottom arrow
		case SB_LINEDOWN:
			si.nPos += 1;
			break;
			// user clicked the scroll bar shaft above the scroll box
		case SB_PAGEUP:
			si.nPos -= si.nPage;
			break;
			// user clicked the scroll bar shaft below the scroll box
		case SB_PAGEDOWN:
			si.nPos += si.nPage;
			break;
			// user dragged the scroll box
		case SB_THUMBTRACK:
			si.nPos = si.nTrackPos;
			break;
		default:
			break; 
		}
		// Set the position and then retrieve it.  Due to adjustments
		// by Windows it may not be the same as the value set.
		si.fMask = SIF_POS;
		SetScrollInfo (hWnd, SB_VERT, &si, TRUE);
		GetScrollInfo (hWnd, SB_VERT, &si);
		// If the position has changed, scroll window and update it
		if (si.nPos != ySBPos)
		{
			ScrollWindow(hWnd, 0, ySBPos - si.nPos, NULL, NULL);
			OffsetRect(&rtMaze, 0, ySBPos - si.nPos);
			ySBPos = si.nPos;
		}
		break;

	case WM_KEYDOWN:

		switch (wParam)
		{
		case VK_F2:
			SendMessage(hWnd, WM_RESET, MAKEWPARAM(RESET_INITIAL, 0), NULL);
			break;
		default:
			if (bInit)
				PostMessage(hwndMaze, message, wParam, lParam);
			break;
		}
		break;

	case WM_ERASEBKGND:
		break;

	case WM_PAINT:

		hdc = BeginPaint(hWnd, &ps);
		// TODO: �ڴ����������ͼ����...
		GetClientRect(hWnd, &rt);
		StretchBlt(hdc, 0, 0, rt.right, rt.bottom, hdcMem, 0, 0, 1, 1, SRCCOPY);
		
		if (!bInit)
			TextOut(hdc, 10, 10, szText, _tcslen(szText));

#ifdef _DEBUG
		CopyRect(&rt, &rtMaze);
		InflateRect(&rt, BLOCK_SIZE, BLOCK_SIZE);
		FrameRect(hdc, &rt, (HBRUSH)GetStockObject(BLACK_BRUSH));
#endif

		EndPaint(hWnd, &ps);
		break;

	case WM_DESTROY:

		if (ppMaze != NULL)
		{
			freeMaze(ppMaze);
			ppMaze = NULL;
		}

		if (pPath != NULL)
		{
			destroyLinkStack(pPath);
			pPath = NULL;
		}

		DeleteDC(hdcMem);
		DeleteObject(hbmpMem);

		PostQuitMessage(0);
		break;

	default:
		return DefWindowProc(hWnd, message, wParam, lParam);
	}
	return 0;
}

LRESULT CALLBACK MazeWndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	PAINTSTRUCT ps;
	HDC hdc;
	RECT rt;

	static HDC hdcMaze = NULL;
	static HBITMAP hbmpMaze = NULL;
	static HDC hdcPath = NULL;
	static HBITMAP hbmpPath = NULL;
	static BITMAPINFO bmiPath;

	static HWND hwndFlt = NULL;		// �����Ӵ���

	static RECT rtFlt;				// �����Ӵ��ھ���
	static RECT rtStay;				// �϶�����ʱ�޳ָ��겻���ľ��η�Χ
	static RECT rtCap;				// �϶�����ʱ�޶������ƶ���Χ

	static POINT ptCursor;			// ��굱ǰλ��

	static RESET_INFO ri;			// ���ݸ������̺߳�����������Ϣ

	static HANDLE hThread = NULL;	// �����߳̾��
	static DWORD dwExitCode;

	switch (message)
	{
	case WM_CREATE:

		hwndFlt = CreateWindow(_T("FloatWnd"), NULL, WS_CHILD,
			0, 0, 0, 0,
			hWnd, NULL, hInst, NULL);
		memset(&bmiPath, 0, sizeof(BITMAPINFO));

		bmiPath.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
		bmiPath.bmiHeader.biPlanes = 1;
		bmiPath.bmiHeader.biBitCount = 1;
		bmiPath.bmiHeader.biCompression = BI_RGB;

		bmiPath.bmiColors[0].rgbBlue = 0xFF;
		bmiPath.bmiColors[0].rgbGreen = 0x00;
		bmiPath.bmiColors[0].rgbRed = 0x00;

		bmiPath.bmiColors[1].rgbBlue = 0xFF;
		bmiPath.bmiColors[1].rgbGreen = 0xFF;
		bmiPath.bmiColors[1].rgbRed = 0xFF;
		break;

	case WM_RESET:

		switch (LOWORD(wParam))
		{
		case RESET_INITIAL:

			// �������߳��������������жϲ��ر�
			if (hThread != NULL)
			{
				GetExitCodeThread(hThread, &dwExitCode);
				TerminateThread(hThread, dwExitCode);
				CloseHandle(hThread);
			}

			// ���㸡����μ��������϶�������صľ���
			SetRect(&rtStay, 0, 0, SQU_SIZE, SQU_SIZE);
			CopyRect(&rtCap, &rtStay);
			CopyRect(&rtFlt, &rtStay);

			InflateRect(&rtCap, ROUTE_SIZE, ROUTE_SIZE);
			InflateRect(&rtFlt, -BLOCK_SIZE, -BLOCK_SIZE);

			InflateRect(&rtStay, BLOCK_SIZE + SQU_MARGIN, BLOCK_SIZE + SQU_MARGIN);
			InflateRect(&rtCap, BLOCK_SIZE + SQU_MARGIN, BLOCK_SIZE + SQU_MARGIN);

			MoveWindow(hwndFlt, rtFlt.left, rtFlt.top,
				rtFlt.right - rtFlt.left, rtFlt.bottom - rtFlt.top, TRUE);

			ShowWindow(hwndFlt, SW_SHOW);

			DeleteDC(hdcMaze);
			DeleteObject(hbmpMaze);

			hdcMaze = CreateCompatibleDC(NULL);
			hbmpMaze = CreateCompatibleBitmap(hdcMaze, nMazeWidth, nMazeHeight);

			// �ж��Թ��Ļ��ƴ�С�Ƿ񳬳����Ʒ�Χ
			if (nMazeWidth <= 0 || nMazeHeight <= 0 || hbmpMaze == NULL)
			{
				DeleteDC(hdcMaze);
				DeleteObject(hbmpMaze);
				// ��������Ϣ���ݸ�������
				PostMessage(GetParent(hWnd), WM_RESET, MAKEWPARAM(RESET_ERROR, ERROR_OUTOFRANGE), NULL);
				break;
			}
			
			SelectObject(hdcMaze, hbmpMaze);

			ri.hwnd = hWnd;
			ri.hdc = hdcMaze;

			// ���������������߳�
			hThread = CreateThread(NULL, 0, ResetThread, &ri, 0, NULL);
			OutputDebugString(_T("Create reset thread\n"));
			break;

		case RESET_COMPLETE:

			// �����������Ϣ���ݸ�������
			PostMessage(GetParent(hWnd), WM_RESET, MAKEWPARAM(RESET_COMPLETE, 0), NULL);
			break;

		default:
			PostMessage(GetParent(hWnd), message, wParam, lParam);
			break;
		}

		break;

	case WM_LBUTTONDOWN:;

		ptCursor.x = LOWORD(lParam);
		ptCursor.y = HIWORD(lParam);

		if (PtInRect(&rtCap, ptCursor))
		{
			CopyRect(&rt, &rtCap);
			MapWindowPoints(hWnd, GetDesktopWindow(), (LPPOINT)&rt, 2);
			ClipCursor(&rt);
		}
		break;

	case WM_LBUTTONUP:

		ClipCursor(NULL);
		break;

	case WM_MOUSEMOVE:

		ptCursor.x = LOWORD(lParam);
		ptCursor.y = HIWORD(lParam);

		//_stprintf_s(szDebug, _T("%d,%d\n"), ptCursor.x, ptCursor.y);
		//OutputDebugString(szDebug);

		if (PtInRect(&rtCap, ptCursor) && wParam == MK_LBUTTON)
		{
			if (ptCursor.x > rtStay.right)
				PostMessage(hWnd, WM_KEYDOWN, VK_RIGHT, NULL);
			else if (ptCursor.x < rtStay.left)
				PostMessage(hWnd, WM_KEYDOWN, VK_LEFT, NULL);
			else if (ptCursor.y > rtStay.bottom)
				PostMessage(hWnd, WM_KEYDOWN, VK_DOWN, NULL);
			else if (ptCursor.y < rtStay.top)
				PostMessage(hWnd, WM_KEYDOWN, VK_UP, NULL);

			PostMessage(hWnd, WM_LBUTTONDOWN, NULL, lParam);
		}
		else
		{
			ClipCursor(NULL);
		}
		break;

	case WM_KEYDOWN:

		if (wParam == VK_RIGHT && pPath == NULL)
		{
			if(dxFlt < cxMaze - 1)
			{
				if ((ppMaze[dxFlt][dyFlt] & BLOCK_RIGHT) == 0)
				{
					OffsetRect(&rtFlt, SQU_SIZE + SQU_MARGIN, 0);
					OffsetRect(&rtStay, SQU_SIZE + SQU_MARGIN, 0);
					OffsetRect(&rtCap, SQU_SIZE + SQU_MARGIN, 0);
					MoveWindow(hwndFlt, rtFlt.left, rtFlt.top,
						rtFlt.right - rtFlt.left, rtFlt.bottom - rtFlt.top, TRUE);
					dxFlt++;
				}
			}
		}
		else if (wParam == VK_DOWN && pPath == NULL)
		{
			if(dyFlt < cyMaze - 1)
			{
				if ((ppMaze[dxFlt][dyFlt] & BLOCK_BOTTOM) == 0)
				{
					OffsetRect(&rtFlt, 0, SQU_SIZE + SQU_MARGIN);
					OffsetRect(&rtStay, 0, SQU_SIZE + SQU_MARGIN);
					OffsetRect(&rtCap, 0, SQU_SIZE + SQU_MARGIN);
					MoveWindow(hwndFlt, rtFlt.left, rtFlt.top,
						rtFlt.right - rtFlt.left, rtFlt.bottom - rtFlt.top, TRUE);
					dyFlt++;
				}
			}
		}
		else if (wParam == VK_LEFT && pPath == NULL)
		{
			if(dxFlt > 0)
			{
				if ((ppMaze[dxFlt][dyFlt] & BLOCK_LEFT) == 0)
				{
					OffsetRect(&rtFlt, -(SQU_SIZE + SQU_MARGIN), 0);
					OffsetRect(&rtStay, -(SQU_SIZE + SQU_MARGIN), 0);
					OffsetRect(&rtCap, -(SQU_SIZE + SQU_MARGIN), 0);
					MoveWindow(hwndFlt, rtFlt.left, rtFlt.top,
						rtFlt.right - rtFlt.left, rtFlt.bottom - rtFlt.top, TRUE);
					dxFlt--;
				}
			}
		}
		else if (wParam == VK_UP && pPath == NULL)
		{
			if(dyFlt > 0)
			{
				if ((ppMaze[dxFlt][dyFlt] & BLOCK_TOP) == 0)
				{
					OffsetRect(&rtFlt, 0, -(SQU_SIZE + SQU_MARGIN));
					OffsetRect(&rtStay, 0, -(SQU_SIZE + SQU_MARGIN));
					OffsetRect(&rtCap, 0, -(SQU_SIZE + SQU_MARGIN));
					MoveWindow(hwndFlt, rtFlt.left, rtFlt.top,
						rtFlt.right - rtFlt.left, rtFlt.bottom - rtFlt.top, TRUE);
					dyFlt--;
				}
			}
		}
		else if (wParam == VK_SPACE && bInit)
		{
			if (pPath == NULL)
			{
				ShowWindow(hwndFlt, SW_HIDE);
				pPath = getPath(ppMaze, cxMaze, cyMaze);

				bmiPath.bmiHeader.biWidth = nMazeWidth;
				bmiPath.bmiHeader.biHeight = nMazeHeight;

				DeleteDC(hdcPath);
				DeleteObject(hbmpPath);

				hdcPath = CreateCompatibleDC(NULL);
				hbmpPath = CreateDIBSection(NULL, &bmiPath, DIB_RGB_COLORS, NULL, NULL, 0);
				SelectObject(hdcPath, hbmpPath);
				DrawPath(hdcPath);
			}
			else
			{
				destroyLinkStack(pPath);
				pPath = NULL;

				DeleteDC(hdcPath);
				DeleteObject(hbmpPath);

				PostMessage(GetParent(hWnd), WM_RESET, MAKEWPARAM(RESET_INITIAL, 0), NULL);
			}
			InvalidateRect(hWnd, NULL, FALSE);
		}

		// �����굽�����ʱ�Զ�������Ϸ
		if (dxFlt == cxMaze - 1 && dyFlt == cyMaze - 1)
			PostMessage(hWnd, WM_RESET, NULL, NULL);

#ifdef _DEBUG
		InvalidateRect(hWnd, NULL, FALSE);
#endif
		break;

	case WM_ERASEBKGND:
		break;

	case WM_PAINT:

		hdc = BeginPaint(hWnd, &ps);

		if (bInit)
			BitBlt(hdc, 0, 0, nMazeWidth, nMazeHeight, hdcMaze, 0, 0, SRCCOPY);

		if (pPath != NULL)
			BitBlt(hdc, 0, 0, nMazeWidth, nMazeHeight, hdcPath, 0, 0, SRCAND);

#ifdef _DEBUG
		FrameRect(hdc, &rtFlt, (HBRUSH)GetStockObject(BLACK_BRUSH));
		FrameRect(hdc, &rtStay, (HBRUSH)GetStockObject(BLACK_BRUSH));
		FrameRect(hdc, &rtCap, (HBRUSH)GetStockObject(BLACK_BRUSH));
#endif

		EndPaint(hWnd, &ps);
		break;

	case WM_DESTROY:

		CloseHandle(hThread);

		DeleteDC(hdcMaze);
		DeleteObject(hbmpMaze);
		DeleteDC(hdcPath);
		DeleteObject(hbmpPath);

		PostQuitMessage(0);
		break;

	default:
		return DefWindowProc(hWnd, message, wParam, lParam);
	}
	return 0;
}

LRESULT CALLBACK FloatWndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	PAINTSTRUCT ps;
	HDC hdc;
	RECT rt;
	POINT pt;
	HBRUSH hbr;

	static COLORREF color = 0x0000FF;

	switch (message)
	{
	case WM_CREATE:
		SetTimer(hWnd, 0, 500, NULL);
		break;

	case WM_TIMER:
		color = (color == 0x0000FF) ? 0xFFFFFF : 0x0000FF;
		InvalidateRect(hWnd, NULL, FALSE);
		break;

	case WM_MOUSEMOVE:
	case WM_LBUTTONDOWN:
	case WM_LBUTTONUP:
		pt.x = LOWORD(lParam);
		pt.y = HIWORD(lParam);
		MapWindowPoints(hWnd, GetParent(hWnd), &pt, 1);
		PostMessage(GetParent(hWnd), message, wParam, MAKELPARAM(pt.x, pt.y));
		break;

	case WM_KEYDOWN:
		PostMessage(GetParent(hWnd), message, wParam, lParam);
		break;

	case WM_PAINT:
		hdc = BeginPaint(hWnd, &ps);
		hbr = CreateSolidBrush(color);
		GetClientRect(hWnd, &rt);
		InflateRect(&rt, -BLOCK_SIZE, -BLOCK_SIZE);
		FillRect(hdc, &rt, hbr);
		DeleteObject(hbr);
		EndPaint(hWnd, &ps);
		break;

	case WM_DESTROY:
		KillTimer(hWnd, 0);
		PostQuitMessage(0);
		break;

	default:
		return DefWindowProc(hWnd, message, wParam, lParam);
	}
	return 0;
}

// �����ڡ������Ϣ��������
LRESULT CALLBACK About(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	UNREFERENCED_PARAMETER(lParam);
	switch (message)
	{
	case WM_INITDIALOG:
		return (LRESULT)TRUE;

	case WM_COMMAND:
		if (LOWORD(wParam) == IDOK || LOWORD(wParam) == IDCANCEL)
		{
			EndDialog(hDlg, LOWORD(wParam));
			return (LRESULT)TRUE;
		}
		break;
	}
	return (LRESULT)FALSE;
}

LRESULT CALLBACK Config(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	int nWidth;
	int nHeight;

	UNREFERENCED_PARAMETER(lParam);
	switch (message)
	{
	case WM_INITDIALOG:
		SetDlgItemInt(hDlg, IDC_WIDTH, cxMaze, FALSE);
		SetDlgItemInt(hDlg, IDC_HEIGHT, cyMaze, FALSE);
		return (LRESULT)TRUE;

	case WM_COMMAND:
		if (LOWORD(wParam) == IDOK || LOWORD(wParam) == IDCANCEL)
		{
			EndDialog(hDlg, LOWORD(wParam));

			if (LOWORD(wParam) == IDOK)
			{
				nWidth = GetDlgItemInt(hDlg, IDC_WIDTH, NULL, FALSE);
				nHeight = GetDlgItemInt(hDlg, IDC_HEIGHT, NULL, FALSE);

				if (nWidth <= 0 || nHeight <= 0)
				{
					MessageBox(GetParent(hDlg), _T("������ֵ����ȷ��"), NULL, MB_OK);
				}
				else
				{
					SendMessage(GetParent(hDlg), WM_RESET, MAKEWPARAM(RESET_INITIAL, 0), MAKELPARAM(nWidth, nHeight));
				}
			}

			return (LRESULT)TRUE;
		}
		break;
	}
	return (LRESULT)FALSE;
}

DWORD WINAPI ResetThread(LPVOID lpParam)
{
	RESET_INFO* pri = (RESET_INFO*)lpParam;

	OutputDebugString(_T("Reset start\n"));
	if (bReAlloc)
	{
		freeMaze(ppMaze);
		ppMaze = allocMaze(cxMaze, cyMaze);
	}

	if (ppMaze != NULL)
	{
		createMaze(ppMaze, cxMaze, cyMaze);
		DrawMaze(pri->hdc);
		RedrawWindow(pri->hwnd, NULL, NULL, RDW_INVALIDATE | RDW_UPDATENOW);
		PostMessage(pri->hwnd, WM_RESET, MAKEWPARAM(RESET_COMPLETE, 0), NULL);
	}
	else
	{
		PostMessage(pri->hwnd, WM_RESET, MAKEWPARAM(RESET_ERROR, ERROR_NOMEMORY), NULL);
	}
	OutputDebugString(_T("Reset stop\n"));

	return 0;
}

void DrawMaze(HDC hdc)
{
	LOGBRUSH lb;
	HPEN hpen = NULL;
	HPEN hpenOld = NULL;
	RECT rtSquare;
	RECT rt;
	int x, y;

	lb.lbStyle = BS_SOLID;
	lb.lbColor = 0x000000;
	hpen = ExtCreatePen(PS_GEOMETRIC | PS_ENDCAP_SQUARE,
		BLOCK_SIZE, &lb, 0, NULL);

	hpenOld = (HPEN)SelectObject(hdc, hpen);

	SetRect(&rt, 0, 0, nMazeWidth, nMazeHeight);
	FillRect(hdc, &rt, NULL);

	SetRect(&rtSquare, 0, 0, SQU_SIZE, SQU_SIZE);

	for (y = 0; y < cyMaze; y++)
	{
		for (x = 0; x < cxMaze; x++)
		{
			if ((ppMaze[x][y] & BLOCK_LEFT) != 0)
			{
				MoveToEx(hdc, rtSquare.left + BLOCK_SIZE / 2, rtSquare.top + BLOCK_SIZE / 2, NULL);
				LineTo(hdc, rtSquare.left + BLOCK_SIZE / 2, rtSquare.bottom - BLOCK_SIZE / 2);
			}

			if ((ppMaze[x][y] & BLOCK_TOP) != 0)
			{
				MoveToEx(hdc, rtSquare.left + BLOCK_SIZE / 2, rtSquare.top + BLOCK_SIZE / 2, NULL);
				LineTo(hdc, rtSquare.right - BLOCK_SIZE / 2, rtSquare.top + BLOCK_SIZE / 2);
			}

			if ((ppMaze[x][y] & BLOCK_RIGHT) != 0)
			{
				MoveToEx(hdc, rtSquare.right - BLOCK_SIZE / 2, rtSquare.top + BLOCK_SIZE / 2, NULL);
				LineTo(hdc, rtSquare.right - BLOCK_SIZE / 2, rtSquare.bottom - BLOCK_SIZE / 2);
			}

			if ((ppMaze[x][y] & BLOCK_BOTTOM) != 0)
			{
				MoveToEx(hdc, rtSquare.left + BLOCK_SIZE / 2, rtSquare.bottom - BLOCK_SIZE / 2, NULL);
				LineTo(hdc, rtSquare.right - BLOCK_SIZE / 2, rtSquare.bottom - BLOCK_SIZE / 2);
			}

			OffsetRect(&rtSquare, SQU_SIZE + SQU_MARGIN, 0);
		}

		OffsetRect(&rtSquare, -(cxMaze * (SQU_SIZE + SQU_MARGIN)), SQU_SIZE + SQU_MARGIN);
	}

	SelectObject(hdc, hpenOld);
	DeleteObject(hpen);
}

void DrawPath(HDC hdc)
{
	LOGBRUSH lb;
	HPEN hpen = NULL;
	HPEN hpenOld = NULL;
	HBRUSH hbr = NULL;
	RECT rtSquare;
	RECT rt;
	int x, y;

	LinkStack* pStack = NULL;
	Route* pRoute = NULL;

	lb.lbStyle = BS_SOLID;
	lb.lbColor = 0xFF0000;
	hpen = ExtCreatePen(PS_GEOMETRIC | PS_ENDCAP_SQUARE,
		BLOCK_SIZE, &lb, 0, NULL);

	hbr = CreateSolidBrush(0xFFFFFF);

	hpenOld = (HPEN)SelectObject(hdc, hpen);

	SetRect(&rt, 0, 0, nMazeWidth, nMazeHeight);
	FillRect(hdc, &rt, hbr);

	pStack = createLinkStack(sizeof(Route));
	copyLinkStack(pStack, pPath);

	SetRect(&rtSquare, 0, 0, SQU_SIZE, SQU_SIZE);

	MoveToEx(hdc, rtSquare.left + BLOCK_SIZE, rtSquare.top + SQU_SIZE / 2, NULL);
	LineTo(hdc, rtSquare.left + SQU_SIZE / 2, rtSquare.top + SQU_SIZE / 2);

	x = 0;
	y = 0;


	while (isLinkStackEmpty(pStack) == 0)
	{
		pRoute = (Route*)getLinkStackTop(pStack)->data;

		if (x < pRoute->x)
		{
			OffsetRect(&rtSquare, SQU_SIZE + SQU_MARGIN, 0);
			LineTo(hdc, rtSquare.left + SQU_SIZE / 2, rtSquare.top + SQU_SIZE / 2);
			x = pRoute->x;
		}
		else if (y < pRoute->y)
		{
			OffsetRect(&rtSquare, 0, SQU_SIZE + SQU_MARGIN);
			LineTo(hdc, rtSquare.left + SQU_SIZE / 2, rtSquare.top + SQU_SIZE / 2);
			y = pRoute->y;
		}
		else if (x > pRoute->x)
		{
			OffsetRect(&rtSquare, -(SQU_SIZE + SQU_MARGIN), 0);
			LineTo(hdc, rtSquare.left + SQU_SIZE / 2, rtSquare.top + SQU_SIZE / 2);
			x = pRoute->x;
		}
		else if (y > pRoute->y)
		{
			OffsetRect(&rtSquare, 0, -(SQU_SIZE + SQU_MARGIN));
			LineTo(hdc, rtSquare.left + SQU_SIZE / 2, rtSquare.top + SQU_SIZE / 2);
			y = pRoute->y;
		}

		popLinkStack(pStack);
	}

	LineTo(hdc, rtSquare.left + SQU_SIZE / 2, rtSquare.bottom - BLOCK_SIZE);

	destroyLinkStack(pStack);
	pStack = NULL;
	pRoute = NULL;

	SelectObject(hdc, hpenOld);
	DeleteObject(hpen);
	DeleteObject(hbr);
}