#pragma once

#include "resource.h"
#include "maze.h"
#include "linkstack.h"

typedef struct _RESET_INFO
{
	HWND	hwnd;
	HDC		hdc;
}RESET_INFO;