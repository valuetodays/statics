#include <stdlib.h>
#include <string.h>
#include "linkstack.h"

LinkStack* createLinkStack(size_t datasize)
{
	LinkStack* top = (LinkStack*)malloc(sizeof(LinkStack));
	top->datasize = datasize;
	top->next = NULL;

	return top;
}

void destroyLinkStack(LinkStack* top)
{
	clearLinkStack(top);
	free(top);
}

void pushLinkStack(LinkStack* top, void* data)
{
	LinkNode* node = (LinkNode*)malloc(sizeof(LinkNode));
	node->data = malloc(top->datasize);
	memcpy(node->data, data, top->datasize);
	node->next = top->next;
	top->next = node;
}

void popLinkStack(LinkStack* top)
{
	LinkNode* node = top->next;
	top->next = node->next;
	free(node->data);
	free(node);
	node = NULL;
}

int isLinkStackEmpty(LinkStack* top)
{
	return (top->next == NULL) ? 1 : 0;
}

LinkNode* getLinkStackTop(LinkStack* top)
{
	return top->next;
}

void copyLinkStack(LinkStack* dst, const LinkStack* src)
{
	LinkNode* srcNode = src->next;
	LinkNode* dstNode = NULL;
	LinkNode* temp = NULL;

	dst->datasize = src->datasize;

	while (srcNode != NULL)
	{
		temp = (LinkNode*)malloc(sizeof(LinkNode));
		temp->data = malloc(dst->datasize);
		memcpy(temp->data, srcNode->data, dst->datasize);

		if (dst->next == NULL)
		{
			dst->next = temp;
			dstNode = temp;
		}
		else
		{
			dstNode->next = temp;
			dstNode = dstNode->next;
		}

		srcNode = srcNode->next;
	}

	dstNode->next = NULL;
}

void invertLinkStack(LinkStack* top)
{
	LinkStack* tempTop = (LinkStack*)malloc(sizeof(LinkNode));
	LinkNode* node = NULL;

	tempTop->next = NULL;

	while (top->next != NULL)
	{
		node = (LinkNode*)malloc(sizeof(LinkNode));
		node->data = top->next->data;
		node->next = tempTop->next;
		tempTop->next = node;
		node = top->next;
		top->next = node->next;
		free(node);
		node = NULL;
	}

	top->next = tempTop->next;

	free(tempTop);
	tempTop = NULL;
}

void clearLinkStack(LinkStack* top)
{
	LinkNode* temp = NULL;

	while (top->next != NULL)
	{
		temp = top->next;
		top->next = temp->next;
		free(temp->data);
		free(temp);
		temp = NULL;
	}
}