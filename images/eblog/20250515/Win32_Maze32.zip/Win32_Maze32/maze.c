#include <stdlib.h>
#include <string.h>
#include <time.h>
#include "maze.h"
#include "linkstack.h"

void pushRoute(LinkStack* top, int x, int y)
{
	Route route;
	route.x = x;
	route.y = y;
	pushLinkStack(top, &route);
}

static int cxMaze = 0;
MazeBuff allocMaze(int cx, int cy)
{
	MazeBuff maze = NULL;
	int x, y;

	maze = (MazeBuff)malloc(sizeof(Byte*)*cx);

	if (maze != NULL)
	{
		for (x = 0; x < cx; x++)
		{
			maze[x] = (Byte*)malloc(sizeof(Byte)*cy);

			if (maze[x] != NULL)
			{
				memset(maze[x], BLOCK_ALL, sizeof(Byte)*cy);
			}
			else
			{
				for (y = 0; y < x; y++)
					free(maze[y]);

				free(maze);
				maze = NULL;
				cxMaze = 0;
				break;
			}
		}

	}

	if (maze != NULL)
		cxMaze = cx;

	return maze;
}

void freeMaze(MazeBuff maze)
{
	int x;

	for (x = 0; x < cxMaze; x++)
		free(maze[x]);

	free(maze);
}

void createMaze(MazeBuff maze, int cx, int cy)
{
	LinkStack* routeStack = createLinkStack(sizeof(Route));
	Route* data = NULL;
	int direction;
	Byte dirState = 0;
	int x, y;

	static unsigned int seed = 0;

	if (seed == 0)
		seed = (unsigned)time(NULL);

	srand(seed);

	seed = rand();

	for (x = 0; x < cx; x++)
		for (y = 0; y < cy; y++)
			maze[x][y] = BLOCK_ALL;

	//pushRoute(routeStack, rand() % cx, rand() % cy);
	pushRoute(routeStack, cx / 2, cy / 2);

	while (isLinkStackEmpty(routeStack) == 0)
	{
		data = (Route*)getLinkStackTop(routeStack)->data;
		x = data->x;
		y = data->y;

		direction = rand() % 4;

		if (x == 0)
			dirState |= BLOCK_LEFT;
		if (y == 0)
			dirState |= BLOCK_TOP;
		if (x == cx - 1)
			dirState |= BLOCK_RIGHT;
		if (y == cy - 1)
			dirState |= BLOCK_BOTTOM;

		if (direction == DIR_RIGHT && (dirState & BLOCK_RIGHT) == 0)
		{
			if ((maze[x + 1][y] & BLOCK_ALL) == BLOCK_ALL)
			{
				maze[x][y] &= ~BLOCK_RIGHT;
				maze[++x][y] &= ~BLOCK_LEFT;
				pushRoute(routeStack, x, y);
				dirState = 0;
			}
			else
			{
				dirState |= BLOCK_RIGHT;
			}
		}
		else if (direction == DIR_DOWN && (dirState & BLOCK_BOTTOM) == 0)
		{
			if ((maze[x][y + 1] & BLOCK_ALL) == BLOCK_ALL)
			{
				maze[x][y] &= ~BLOCK_BOTTOM;
				maze[x][++y] &= ~BLOCK_TOP;
				pushRoute(routeStack, x, y);
				dirState = 0;
			}
			else
			{
				dirState |= BLOCK_BOTTOM;
			}
		}
		else if (direction == DIR_LEFT && (dirState & BLOCK_LEFT) == 0)
		{
			if ((maze[x - 1][y] & BLOCK_ALL) == BLOCK_ALL)
			{
				maze[x][y] &= ~BLOCK_LEFT;
				maze[--x][y] &= ~BLOCK_RIGHT;
				pushRoute(routeStack, x, y);
				dirState = 0;
			}
			else
			{
				dirState |= BLOCK_LEFT;
			}
		}
		else if (direction == DIR_UP && (dirState & BLOCK_TOP) == 0)
		{
			if ((maze[x][y - 1] & BLOCK_ALL) == BLOCK_ALL)
			{
				maze[x][y] &= ~BLOCK_TOP;
				maze[x][--y] &= ~BLOCK_BOTTOM;
				pushRoute(routeStack, x, y);
				dirState = 0;
			}
			else
			{
				dirState |= BLOCK_TOP;
			}
		}

		if (dirState == BLOCK_ALL)
		{
			popLinkStack(routeStack);
			dirState = 0;
		}

	}//end while (routeStack->next != NULL)

	destroyLinkStack(routeStack);
	routeStack = NULL;

	maze[0][0] &= ~BLOCK_LEFT;
	maze[cx - 1][cy - 1] &= ~BLOCK_BOTTOM;
}

LinkStack* getPath(MazeBuff maze, int cx, int cy)
{
	LinkStack* routeStack = createLinkStack(sizeof(Route));
	Route* data = NULL;
	Byte dirState = 0;
	int x = 0, y = 0;

	pushRoute(routeStack, 0, 0);
	maze[0][0] |= ROUTE_FLAG;

	while (x != cx - 1 || y != cy - 1)
	{
		if (x == 0 || (maze[x][y] & BLOCK_LEFT) != 0)
			dirState |= BLOCK_LEFT;
		if (y == 0 || (maze[x][y] & BLOCK_TOP) != 0)
			dirState |= BLOCK_TOP;
		if (x == cx - 1 || (maze[x][y] & BLOCK_RIGHT) != 0)
			dirState |= BLOCK_RIGHT;
		if (y == cy - 1 || (maze[x][y] & BLOCK_BOTTOM) != 0)
			dirState |= BLOCK_BOTTOM;

		while (x < cx - 1 && (maze[x][y] & BLOCK_RIGHT) == 0)
		{
			if ((maze[x + 1][y] & ROUTE_FLAG) == 0)
			{
				maze[++x][y] |= ROUTE_FLAG;
				pushRoute(routeStack, x, y);
				dirState = 0;
			}
			else
			{
				dirState |= BLOCK_RIGHT;
				break;
			}
		}

		while (y < cy - 1 && (maze[x][y] & BLOCK_BOTTOM) == 0)
		{
			if ((maze[x][y + 1] & ROUTE_FLAG) == 0)
			{
				maze[x][++y] |= ROUTE_FLAG;
				pushRoute(routeStack, x, y);
				dirState = 0;
			}
			else
			{
				dirState |= BLOCK_BOTTOM;
				break;
			}
		}

		while (x > 0 && (maze[x][y] & BLOCK_LEFT) == 0)
		{
			if ((maze[x - 1][y] & ROUTE_FLAG) == 0)
			{
				maze[--x][y] |= ROUTE_FLAG;
				pushRoute(routeStack, x, y);
				dirState = 0;
			}
			else
			{
				dirState |= BLOCK_LEFT;
				break;
			}
		}

		while (y > 0 && (maze[x][y] & BLOCK_TOP) == 0)
		{
			if ((maze[x][y - 1] & ROUTE_FLAG) == 0)
			{
				maze[x][--y] |= ROUTE_FLAG;
				pushRoute(routeStack, x, y);
				dirState = 0;
			}
			else
			{
				dirState |= BLOCK_TOP;
				break;
			}
		}

		if (dirState == BLOCK_ALL)
		{
			popLinkStack(routeStack);
			dirState = 0;
		}

		data = (Route*)getLinkStackTop(routeStack)->data;
		x = data->x;
		y = data->y;
	}

	for (x = 0; x < cx; x++)
		for (y = 0; y < cy; y++)
			maze[x][y] &= ~ROUTE_FLAG;

	invertLinkStack(routeStack);

	return routeStack;
}