#ifndef __LINKSTACK_H__
#define __LINKSTACK_H__

#ifdef  __cplusplus
extern "C" {
#endif

typedef struct _LinkNode
{
	void*	data;
	struct _LinkNode*	next;
}LinkNode;

typedef struct _LinkStack
{
	size_t	datasize;
	LinkNode*	next;
}LinkStack;

LinkStack* createLinkStack(size_t datasize);
void destroyLinkStack(LinkStack* top);
void pushLinkStack(LinkStack* top, void* data);
void popLinkStack(LinkStack* top);
int isLinkStackEmpty(LinkStack* top);
LinkNode* getLinkStackTop(LinkStack* top);
void copyLinkStack(LinkStack* dst, const LinkStack* src);
void invertLinkStack(LinkStack* top);
void clearLinkStack(LinkStack* top);

#ifdef  __cplusplus
}
#endif

#endif /*__LINKSTACK_H__*/