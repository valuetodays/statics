#ifndef __MAZE_H__
#define __MAZE_H__

#ifdef  __cplusplus
extern "C" {
#endif

#include "linkstack.h"

#define BLOCK_LEFT		0x01
#define BLOCK_TOP		0x02
#define BLOCK_RIGHT		0x04
#define BLOCK_BOTTOM	0x08
#define	BLOCK_ALL		0x0F

#define ROUTE_FLAG		0x10
#define ROUTE_SOLUTION	0x20

#define DIR_LEFT	0
#define DIR_UP		1
#define DIR_RIGHT	2
#define DIR_DOWN	3

typedef unsigned char Byte;
typedef Byte** MazeBuff;

typedef struct _Route
{
	int x;
	int y;
}Route;

void pushRoute(LinkStack* top, int x, int y);
MazeBuff allocMaze(int cx, int cy);
void freeMaze(MazeBuff maze);
void createMaze(MazeBuff maze, int cx, int cy);
LinkStack* getPath(MazeBuff maze, int cx, int cy);

#ifdef  __cplusplus
}
#endif

#endif /*__MAZE_H__*/