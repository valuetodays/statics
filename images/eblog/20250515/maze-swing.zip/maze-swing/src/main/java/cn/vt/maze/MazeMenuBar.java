package cn.vt.maze;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;

// 迷宫菜单类
public class MazeMenuBar extends JMenuBar {
    private JFrame frame;
    private MazePanel mazePanel;
    private Maze maze;
    private int currentSize = 32;

    public MazeMenuBar(JFrame frame, MazePanel mazePanel, Maze maze) {
        this.frame = frame;
        this.mazePanel = mazePanel;
        this.maze = maze;
        
        // 创建"游戏"菜单
        JMenu gameMenu = new JMenu("游戏");
        gameMenu.setMnemonic(KeyEvent.VK_G);
        
        // 新游戏菜单项
        JMenuItem newGameItem = new JMenuItem("新游戏", KeyEvent.VK_N);
        newGameItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_N, ActionEvent.CTRL_MASK));
        newGameItem.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                restartGame();
            }
        });
        
        // 难度选择子菜单
        JMenu difficultyMenu = new JMenu("难度");
        ButtonGroup difficultyGroup = new ButtonGroup();
        
        JRadioButtonMenuItem easyItem = new JRadioButtonMenuItem("简单 (16x16)");
        easyItem.setSelected(currentSize == 16);
        easyItem.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (currentSize != 16) {
                    currentSize = 16;
                    restartGame();
                }
            }
        });
        
        JRadioButtonMenuItem mediumItem = new JRadioButtonMenuItem("中等 (32x32)");
        mediumItem.setSelected(currentSize == 32);
        mediumItem.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (currentSize != 32) {
                    currentSize = 32;
                    restartGame();
                }
            }
        });
        
        JRadioButtonMenuItem hardItem = new JRadioButtonMenuItem("困难 (64x64)");
        hardItem.setSelected(currentSize == 64);
        hardItem.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (currentSize != 64) {
                    currentSize = 64;
                    restartGame();
                }
            }
        });
        
        difficultyGroup.add(easyItem);
        difficultyGroup.add(mediumItem);
        difficultyGroup.add(hardItem);
        
        difficultyMenu.add(easyItem);
        difficultyMenu.add(mediumItem);
        difficultyMenu.add(hardItem);
        
        // 退出菜单项
        JMenuItem exitItem = new JMenuItem("退出", KeyEvent.VK_X);
        exitItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_F4, ActionEvent.ALT_MASK));
        exitItem.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.exit(0);
            }
        });
        
        // 添加菜单项到游戏菜单
        gameMenu.add(newGameItem);
        gameMenu.addSeparator();
        gameMenu.add(difficultyMenu);
        gameMenu.addSeparator();
        gameMenu.add(exitItem);
        
        // 创建"帮助"菜单
        JMenu helpMenu = new JMenu("帮助");
        helpMenu.setMnemonic(KeyEvent.VK_H);
        
        // 操作说明菜单项
        JMenuItem instructionsItem = new JMenuItem("操作说明", KeyEvent.VK_I);
        instructionsItem.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                showInstructions();
            }
        });
        
        // 关于菜单项
        JMenuItem aboutItem = new JMenuItem("关于", KeyEvent.VK_A);
        aboutItem.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                showAbout();
            }
        });
        
        // 添加菜单项到帮助菜单
        helpMenu.add(instructionsItem);
        helpMenu.addSeparator();
        helpMenu.add(aboutItem);
        
        // 将菜单添加到菜单栏
        add(gameMenu);
        add(helpMenu);
    }
    
    private void restartGame() {
        // 创建新迷宫
        maze = new Maze(currentSize, currentSize);
        
        // 更新面板
        frame.getContentPane().remove(mazePanel);
        mazePanel = new MazePanel(maze);
        frame.getContentPane().add(mazePanel);
        
        // 重新布局并请求焦点
        frame.pack();
        mazePanel.requestFocusInWindow();
    }
    
    private void showInstructions() {
        StringBuilder instructions = new StringBuilder();
        instructions.append("迷宫游戏操作说明:\n\n");
        instructions.append("方向键: 移动玩家\n");
        instructions.append("空格键: 显示/隐藏最短路径\n");
        instructions.append("Ctrl+N: 开始新游戏\n");
        instructions.append("Alt+F4: 退出游戏\n\n");
        instructions.append("目标: 从左上角找到路径到达右下角");
        
        JOptionPane.showMessageDialog(frame, instructions.toString(), "操作说明", JOptionPane.INFORMATION_MESSAGE);
    }
    
    private void showAbout() {
        StringBuilder about = new StringBuilder();
        about.append("迷宫游戏 v1.0\n\n");
        about.append("使用Java Swing开发\n");
        about.append("支持键盘操作和菜单控制\n");
        about.append("包含三种难度级别");
        
        JOptionPane.showMessageDialog(frame, about.toString(), "关于", JOptionPane.INFORMATION_MESSAGE);
    }
}