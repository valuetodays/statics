package cn.vt.maze;

import javax.swing.*;
import java.awt.*;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.util.*;
import java.util.List;

// 迷宫面板类
public class MazePanel extends JPanel {
    private final Maze maze;
    private int cellSize = 20;
    private int playerX = 0;
    private int playerY = 0;
    private boolean showPath = false;
    private List<int[]> path = new ArrayList<>();

    public MazePanel(Maze maze) {
        this.maze = maze;
        setPreferredSize(new Dimension(maze.getWidth() * cellSize, maze.getHeight() * cellSize));
        addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                int key = e.getKeyCode();
                switch (key) {
                    case KeyEvent.VK_RIGHT:
                        if (playerX < maze.getWidth() - 1 && (maze.getMaze()[playerX][playerY] & 0x04) == 0) {
                            playerX++;
                        }
                        break;
                    case KeyEvent.VK_DOWN:
                        if (playerY < maze.getHeight() - 1 && (maze.getMaze()[playerX][playerY] & 0x08) == 0) {
                            playerY++;
                        }
                        break;
                    case KeyEvent.VK_LEFT:
                        if (playerX > 0 && (maze.getMaze()[playerX][playerY] & 0x01) == 0) {
                            playerX--;
                        }
                        break;
                    case KeyEvent.VK_UP:
                        if (playerY > 0 && (maze.getMaze()[playerX][playerY] & 0x02) == 0) {
                            playerY--;
                        }
                        break;
                    case KeyEvent.VK_SPACE:
                        showPath = !showPath;
                        if (showPath && path.isEmpty()) {
                            findPath();
                        }
                        repaint();
                        break;
                }
                repaint();
                if (playerX == maze.getWidth() - 1 && playerY == maze.getHeight() - 1) {
                    JOptionPane.showMessageDialog(null, "恭喜你，成功走出迷宫！");
                }
            }
        });
        setFocusable(true);
    }

    private void findPath() {
        path.clear();
        boolean[][] visited = new boolean[maze.getWidth()][maze.getHeight()];
        Queue<int[]> queue = new LinkedList<>();
        Map<String, int[]> parentMap = new HashMap<>();

        int startX = 0;
        int startY = 0;
        int endX = maze.getWidth() - 1;
        int endY = maze.getHeight() - 1;

        queue.offer(new int[]{startX, startY});
        visited[startX][startY] = true;

        while (!queue.isEmpty()) {
            int[] current = queue.poll();
            int x = current[0];
            int y = current[1];

            if (x == endX && y == endY) {
                // 构建路径
                Stack<int[]> pathStack = new Stack<>();
                while (x != startX || y != startY) {
                    pathStack.push(new int[]{x, y});
                    int[] parent = parentMap.get(x + "," + y);
                    x = parent[0];
                    y = parent[1];
                }
                pathStack.push(new int[]{startX, startY});

                // 反转栈得到正确顺序
                while (!pathStack.isEmpty()) {
                    path.add(pathStack.pop());
                }
                return;
            }

            // 右
            if (x < maze.getWidth() - 1 && (maze.getMaze()[x][y] & 0x04) == 0 && !visited[x + 1][y]) {
                queue.offer(new int[]{x + 1, y});
                visited[x + 1][y] = true;
                parentMap.put((x + 1) + "," + y, new int[]{x, y});
            }

            // 下
            if (y < maze.getHeight() - 1 && (maze.getMaze()[x][y] & 0x08) == 0 && !visited[x][y + 1]) {
                queue.offer(new int[]{x, y + 1});
                visited[x][y + 1] = true;
                parentMap.put(x + "," + (y + 1), new int[]{x, y});
            }

            // 左
            if (x > 0 && (maze.getMaze()[x][y] & 0x01) == 0 && !visited[x - 1][y]) {
                queue.offer(new int[]{x - 1, y});
                visited[x - 1][y] = true;
                parentMap.put((x - 1) + "," + y, new int[]{x, y});
            }

            // 上
            if (y > 0 && (maze.getMaze()[x][y] & 0x02) == 0 && !visited[x][y - 1]) {
                queue.offer(new int[]{x, y - 1});
                visited[x][y - 1] = true;
                parentMap.put(x + "," + (y - 1), new int[]{x, y});
            }
        }
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        byte[][] mazeData = maze.getMaze();
        
        // 绘制背景
        g.setColor(Color.WHITE);
        g.fillRect(0, 0, getWidth(), getHeight());
        
//        // 绘制路径
//        if (showPath && !path.isEmpty()) {
//            g.setColor(new Color(222, 206, 67, 150)); // 半透明黄色
//            for (int i = 0; i < path.size(); i++) {
//                int[] p = path.get(i);
//                int x = p[0] * cellSize + 2;
//                int y = p[1] * cellSize + 2;
//                g.fillRect(x, y, cellSize - 4, cellSize - 4);
//            }
//        }

        // 绘制路径（修改部分）
        if (showPath && !path.isEmpty()) {
            g.setColor(new Color(255, 69, 0, 180)); // 半透明橙色

            int centerX = path.getFirst()[0] * cellSize + cellSize / 2;
            int centerY = path.getFirst()[1] * cellSize + cellSize / 2;

            // 绘制起点标记
            g.fillOval(centerX - 4, centerY - 4, 8, 8);

            // 连接路径点
            for (int i = 1; i < path.size(); i++) {
                int[] p = path.get(i);
                int nextX = p[0] * cellSize + cellSize / 2;
                int nextY = p[1] * cellSize + cellSize / 2;

                g.drawLine(centerX, centerY, nextX, nextY);
                centerX = nextX;
                centerY = nextY;
            }

            // 绘制终点标记
            g.fillOval(centerX - 4, centerY - 4, 8, 8);
        }

        // 绘制迷宫
        g.setColor(Color.BLACK);
        for (int y = 0; y < maze.getHeight(); y++) {
            for (int x = 0; x < maze.getWidth(); x++) {
                int left = x * cellSize;
                int top = y * cellSize;
                if ((mazeData[x][y] & 0x01) != 0) {
                    g.drawLine(left, top, left, top + cellSize);
                }
                if ((mazeData[x][y] & 0x02) != 0) {
                    g.drawLine(left, top, left + cellSize, top);
                }
                if ((mazeData[x][y] & 0x04) != 0) {
                    g.drawLine(left + cellSize, top, left + cellSize, top + cellSize);
                }
                if ((mazeData[x][y] & 0x08) != 0) {
                    g.drawLine(left, top + cellSize, left + cellSize, top + cellSize);
                }
            }
        }
        
        // 绘制玩家
        g.setColor(Color.RED);
        g.fillRect(playerX * cellSize + 2, playerY * cellSize + 2, cellSize - 4, cellSize - 4);
    }
}