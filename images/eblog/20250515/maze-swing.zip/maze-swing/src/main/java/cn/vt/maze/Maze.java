package cn.vt.maze;

import java.util.Random;
import java.util.Stack;

// 迷宫类
public class Maze {
    private int width;
    private int height;
    private byte[][] maze;

    public Maze(int width, int height) {
        this.width = width;
        this.height = height;
        this.maze = new byte[width][height];
        generateMaze();
    }

    private void generateMaze() {
        Random random = new Random();
        Stack<int[]> stack = new Stack<>();
        byte dirState;
        int x, y;

        // 初始化迷宫
        for (x = 0; x < width; x++) {
            for (y = 0; y < height; y++) {
                maze[x][y] = (byte) 0x0F;
            }
        }

        x = width / 2;
        y = height / 2;
        stack.push(new int[]{x, y});

        while (!stack.isEmpty()) {
            int[] current = stack.pop();
            x = current[0];
            y = current[1];
            dirState = 0;

            if (x == 0) dirState |= 0x01;
            if (y == 0) dirState |= 0x02;
            if (x == width - 1) dirState |= 0x04;
            if (y == height - 1) dirState |= 0x08;

            int[] directions = {0, 1, 2, 3};
            shuffleArray(directions, random);

            for (int dir : directions) {
                switch (dir) {
                    case 2: // 右
                        if ((dirState & 0x04) == 0 && maze[x + 1][y] == 0x0F) {
                            maze[x][y] &= ~0x04;
                            maze[++x][y] &= ~0x01;
                            stack.push(new int[]{x, y});
                            break;
                        } else {
                            dirState |= 0x04;
                        }
                        break;
                    case 3: // 下
                        if ((dirState & 0x08) == 0 && maze[x][y + 1] == 0x0F) {
                            maze[x][y] &= ~0x08;
                            maze[x][++y] &= ~0x02;
                            stack.push(new int[]{x, y});
                            break;
                        } else {
                            dirState |= 0x08;
                        }
                        break;
                    case 0: // 左
                        if ((dirState & 0x01) == 0 && maze[x - 1][y] == 0x0F) {
                            maze[x][y] &= ~0x01;
                            maze[--x][y] &= ~0x04;
                            stack.push(new int[]{x, y});
                            break;
                        } else {
                            dirState |= 0x01;
                        }
                        break;
                    case 1: // 上
                        if ((dirState & 0x02) == 0 && maze[x][y - 1] == 0x0F) {
                            maze[x][y] &= ~0x02;
                            maze[x][--y] &= ~0x08;
                            stack.push(new int[]{x, y});
                            break;
                        } else {
                            dirState |= 0x02;
                        }
                        break;
                }
            }
        }

        // 打开入口和出口
        maze[0][0] &= ~0x01;
        maze[width - 1][height - 1] &= ~0x08;
    }

    private void shuffleArray(int[] array, Random rnd) {
        for (int i = array.length - 1; i > 0; i--) {
            int index = rnd.nextInt(i + 1);
            int temp = array[index];
            array[index] = array[i];
            array[i] = temp;
        }
    }

    public byte[][] getMaze() {
        return maze;
    }

    public int getWidth() {
        return width;
    }

    public int getHeight() {
        return height;
    }
}