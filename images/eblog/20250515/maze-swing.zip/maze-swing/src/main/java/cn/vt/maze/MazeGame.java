package cn.vt.maze;

import javax.swing.*;

// 主窗口类
public class MazeGame extends JFrame {
    private Maze maze;
    private MazePanel mazePanel;
    private MazeMenuBar menuBar;

    public MazeGame() {
        // 创建迷宫
        maze = new Maze(32, 32);
        
        // 创建面板
        mazePanel = new MazePanel(maze);
        
        // 添加面板到窗口
        add(mazePanel);
        
        // 创建并设置菜单栏
        menuBar = new MazeMenuBar(this, mazePanel, maze);
        setJMenuBar(menuBar);
        
        // 设置窗口属性
        pack();
        setTitle("迷宫游戏");
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setResizable(false);
        setVisible(true);
        
        // 请求面板焦点以便接收键盘事件
        mazePanel.requestFocusInWindow();
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(MazeGame::new);
    }
}